*********** Dependencies **************
1) Install Python 2.7.XX if you don't have Python 2.X.XX installed already.
	The latest Python 2.7.16 can be downloaded from this link.
	
	https://www.python.org/downloads/release/python-2716/

2) Install matplotlib library if you don't have it installed already.

	Installation steps:
	- Open a command terminal.
	- Enter these commands:
		- python -m pip install -U pip
		- python -m pip install -U matplotlib

************* Run simulation ***************

	1) Fault-Tolerant Round-Robin

	Steps to run simulation for Fault-Tolerant Round-Robin scheduling. (FaultTolerantRoundRobin.py)

		- Open a command terminal.
		- Go to FaultTolerantScheduling\Simulation directory
			- cd <\path\to\FaultTolerantScheduling\Simulation>
		- Run FaultTolerantRoundRobin.py file
			- python FaultTolerantRoundRobin.py
		- Wait for the simulation to end. It generates a gantt chart FaultTolerantRoundRobin.pdf within same directory.
		- Open FaultTolerantRoundRobin.pdf to analyze the simulation results.

	 

	2) Fault-Tolerant Deadline-Monotonic
		
	Steps to run simulation for Fault-Tolerant Deadline-Monotonic scheduling. (FaultTolerantDeadlineMonotonic.py)
		- Open a terminal.
		- Go to FaultTolerantScheduling\Simulation directory
			- cd <\path\to\FaultTolerantScheduling\Simulation>
		- Run FaultTolerantDeadlineMonotonic.py file
			- python FaultTolerantDeadlineMonotonic.py
		- Wait for the simulation to end. It generates a gantt chart FaultTolerantDeadlineMonotonic.pdf within same directory.
		- Open FaultTolerantDeadlineMonotonic.pdf to analyze the simulation results.

By default the task runs for 100 time units to keep the simulation and Gantt chart light weight. 
If you want to modify the runtime, change RUNTIME definition in corresponding <algorithm>.py file.
for example, RUNTIME = 1000 will run the simulation for 1000 time units.

By default MTTF is set to 25, i.e. one fault will occur randomly within every 25 time units. If you want to modify
MTTF, change MTTF definition in corresponding <algorithm>.py file. For example, MTTF = 50 will set he Mean time to failure
as 50.
	
******* Folder Structure ***********
FaultTolerantScheduling
	|-Simulation
		|-FaultTolerantDeadlineMonotonic.py (Python implementation of Fault-Tolerant Deadline-Monotonic scheduling)
		|-FaultTolerantRoundRobin.py (Python implementation of Fault-Tolerant Round-Robin scheduling)
		|-taskfile.txt (a list of tasks in "TaskName	ExecutionTime	Deadline	Period	Color" format) 
		|-FaultTolerantDeadlineMonotonicExampleGantt.pdf (An example Gantt chart for FTDM - 20 tasks - runtime 1000)
		|-FaultTolerantRoundRobinExampleGantt.pdf (An example Gantt chart for FTRR - 20 tasks - runtime 1000)
		|-TaskGenerator.txt (A random task generator program to generate 20 tasksets of with utilization varying from 50% to 90%)
							(The file is renamed as .txt to allow sending it via emails. If you want to test this simulator open a command
							prompt at this folder and enter command "ren TaskGenerator.txt TaskGenerator.exe". Now you can run TaskGenerator.exe
							by double clicking it on Windows, it will generate 10 taskfiles in the same directory and a utilization.txt to show the
							utilization for each file.)
	|-Papers (Reference papers I had used during simulation)
		|-INTELLEGENT_SLICE_RR.pdf (For intelligent slice implementation for round-robin)
		|-RTS_FT_Algorithms (For round-robin)
		|-Survey_Scheduling_Approaches_RTS (For deadline-monotonic)
	|-Report_ROGATIYA_MOHMAD_ASPAK_ARIF_A0179741U (Simulation report)
	|-README.txt
